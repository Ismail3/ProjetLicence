<html>
    <head>
       <meta charset="utf-8">
        <!-- importer le fichier de style -->
        <link rel="stylesheet" href="styles\inscription.css" media="screen" type="text/css" />
    </head>
    <body>
        <div id="container">
            <!-- zone de connexion -->
            
            <form method="POST"> <!-- La methode poste n'envoie pas les données sur l'url-->
                <h1>Authentification</h1>
                
                <label><b>Login</b></label>
                <input type="text" placeholder="Entrer votre login" name="login" required>

                <label><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer le mot de passe" name="mot_de_passe" required>  <!-- REQUIRED = CHAMP OBLIGATOIRE -->

                <input type="submit" id='submit' value='LOGIN' >
                
                <?php
                
                //lors de l'envoi du formulaire avec le bouton login
                if(count($_POST)>0)
                {
                    //connexion à la BD
                    $conn =  new mysqli("localhost","root","root","autoMarket");

                    //requete pour savoir si les données saisies sont correctes
                    $sql = "SELECT * FROM user WHERE login='" . $_POST["login"] . "' and motdepasse='" . $_POST["mot_de_passe"]."'";

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    if ($result=mysqli_query($conn,$sql)) 
                    {
                        //nombre de resultat
                        $count = mysqli_num_rows($result);

                        //Afficher message selon le resultat de la requete
                        if ($count == 0)
                        {
                            echo  "Login et/ou mot de passe invalides !";
                        }
                        else 
                        {
                            //echo  "Vous êtes connectés avec succès !";

                            header('Location: indexAM.php') ;
                        }
                    } else {
                    echo "Erreur: " . $sql . "<br>" . $conn->error;
                    }
                     $conn->close();
                }

                



                ?>

                <input type="submit" value="INSCRIPTION" OnClick="window.location.href='inscription.php'" />
            </form>
        </div>
    </body>
</html>