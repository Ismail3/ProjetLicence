<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Offres</title>
       <link rel="stylesheet" href="styles/index.css" media="screen" type="text/css" />
    </head>

    <body>
    
<div id="market">
   <h1 id="maVoiture"> <center> VOITURE PLUS  </center> </h1>

</div>

<div id="menu">

  <ul id="onglets">

    <li class="active"><a href="indexAM.php"> Accueil </a></li>

    <li><a href="offres.php"> Offres </a></li>

    <li><a href="publier.php"> Publier mon annonce </a></li>

    <li><a href="inscription.php"> S'inscrire </a></li>

    <li><a href="login.php"> Se connecter </a></li>

  </ul>

</div>



      <h1>Offres</h1>    
      

<table class='off-table'>
<tr>
  <th> <p>TITRE </p></th>
  <th> <p>DATE DE PUBLICATION </p></th>
  <th> <p>PRIX</p> </th>
  <th> <p>MARQUE</p> </th>
  <th> <p>MODELE</p> </th>
  <th> <p>ANNEE</p> </th>
  
</tr>

<?php

  // Create connection
  $conn = new mysqli("localhost", "root", "root","autoMarket");
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT * FROM annonce";   

  $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            
         echo "<tr>".
            "<td><a href='annonce.php?ann_id=" . $row['id_annonce'] . "' target='_blank'> " . $row['titre'] . "</a></td>";
         echo "<td>".$row['date_publication']."</td>";
         echo "<td>".$row['prix']."</td>";
         echo "<td>".$row['marque']."</td>";
         echo "<td>".$row['modele']."</td>";
         echo "<td>".$row['annee']."</td></tr>";

        }
    } else {
        echo "0 results";
    }


$conn->close();
?> 

</table>




   </body>
</html>
