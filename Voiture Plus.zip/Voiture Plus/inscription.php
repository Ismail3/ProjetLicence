<html>
    <head>
       <meta charset="utf-8">
        <!-- importer le fichier de style -->
        <link rel="stylesheet" href="styles/inscription.css" media="screen" type="text/css" />
    </head>
    <body>
        <div id="container">
            <!-- zone de connexion -->
            
            <form  method="POST">
                <h1>Inscription</h1>
                
                <label><b>Nom d'utilisateur</b></label>
                <input type="text" placeholder="Entrer votre nom" name="nom" required>

                <label><b>Prénom de l'utilisateur</b></label>
                <input type="text" placeholder="Entrer votre prénom" name="prenom" required> 

                <label><b>Email</b></label>
                <input type="text" placeholder="Entrer votre email" name="email" required> 

                <label><b>Login</b></label>
                <input type="text" placeholder="Entrer votre login" name="login" required>

                <label><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer le mot de passe" name="mot_de_passe" required>

                 <label><b>Téléphone</b></label>
                <input type="text" placeholder="Entrer votre prénom" name="tel" required>

                <label><b>Adresse</b></label>
                <input type="text" placeholder="Entrer votre adresse" name="adresse" required>


                


                <input type="submit" name='submit' value="S'INSCRIRE" >

                 <?php
                 if(isset($_POST['submit'])){
                $servername = "localhost";
                $username = "root";
                $password = "root";
                $dbname = "autoMarket";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }


                $sql = "INSERT INTO user (nom, prenom, email,login, motdepasse, tel, adresse)
                VALUES ('".$_POST["nom"]."','".$_POST["prenom"]."','".$_POST["email"]."','".$_POST["login"]."','".$_POST["mot_de_passe"]."','".$_POST["tel"]."','".$_POST["adresse"]."')";

                
                if ($conn->query($sql) === TRUE) {
                    echo "Votre nouveau compte a été crée avec succès";
                } else {
                    echo "Erreur: " . $sql . "<br>" . $conn->error;
                }

                $conn->close();
                }

                ?>
            </form>
        </div>
    </body>
</html>