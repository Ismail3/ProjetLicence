<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Acceuil</title>
       <link rel="stylesheet" href="styles/index.css" media="screen" type="text/css" />
    </head>

    <body>

    
    <div id="market">
   <h1 id="maVoiture"> <center> VOITURE PLUS </center> </h1>
</div>
<!--le menu principal-->
 <div id="bloc_page">
    <header>
      <img src="images/icone.png" alt="Logo_page" title="Accueil" id="logo"/>
</header>
</div>
<div id="menu">

  <ul id="onglets">

    <li class="active"><a href="acceuil.php"> Accueil </a></li>
    
    <li><a href="indexAM.php"> Recherche </a></li>


    <li><a href="offres.php"> Offres </a></li>

    <li><a href="publier.php"> Publier mon annonce </a></li>

    <li><a href="inscription.php"> S'inscrire </a></li>

    <li><a href="login.php"> Se connecter </a></li>

  </ul>

</div>

 



<blockquote>
    <p>Auto-market est une application web facilitant la mise en relation entre les vendeurs de voitures d’occasions et les acheteurs potentiels à travers des annonces expliquant l’état mécanique et électronique d’une voiture avec précision.
</p><BR>


</blockquote>



    </body>
</html>