<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Publier mon annonce</title>
       <link rel="stylesheet" href="styles/inscription.css" media="screen" type="text/css" />
        <link rel="stylesheet" href="styles/index.css" media="screen" type="text/css" />
    </head>

    <body id="bodyIndex">

<div id="menu">
<ul id="onglets">
<li class="active"><a href="acceuil.php"> Accueil </a></li>
<li><a href="indexAM.php"> Recherche </a></li>
<li><a href="offres.php"> Offres </a></li>
<li><a href="publier.php"> Publier mon annonce </a></li>
<li><a href="inscription.php"> S'inscrire </a></li>
<li><a href="login.php"> Se connecter </a></li>
</ul>
</div>


<!--<div id="market">
   <h1> <center> AutoMarket </center> </h1>
</div>-->


            <h1>  Saisissez votre annonce</h1>
        
        <div id="container">
            

            <form  method="POST">
                <h3>Complétez les détails de votre annonce</h3>
                
                <label><b>Titre</b></label>
                <input type="text" name="titre" required>

                <label><b>Prix</b></label>
                <input type="text" name="prix" required> 

                <label for="marque"><b>Marque</b></label>

                 <select name="marque">
                <option value="Choisissez">Choisissez</option>
                 <option value="Renault"> Renault</option>
                 <option value="Peugeot">Peugeot</option>
                 <option value="Citroen">Citroen</option>
                 <option value="Dacia">Dacia</option>
                 <option value="Mercedes">Mercedes</option>
                 <option value="Audi">Audi</option>
                 <option value="Voldswagen">Voldswagen</option>
                 <option value="Bmw">Bmw</option>
                 <option value="Opel">Opel</option>
                 <option value="Ford">Ford</option>


                 </select>

                <label><b>Modèle</b></label>
                <input type="text" name="modele" required>

                
<label for="marque"><b>Année</b></label>

                <?php
  // Variable qui ajoutera l'attribut selected de la liste déroulante
  $selected = '';
 
  // Parcours du tableau
  echo '<select name="annee">',"\n";
  for($i=1970; $i<=2030; $i++)
  {
    // L'année est-elle l'année courante ?
    if($i == date('Y'))
    {
      $selected = ' selected="selected"';
    }
    // Affichage de la ligne
    echo "\t",'<option value="', $i ,'"', $selected ,'>', $i ,'</option>',"\n";
    // Remise à zéro de $selected
    $selected='';
  }
  echo '</select>',"\n";
?>




               <!-- <label><b>Carburant</b></label>
                <input type="text" name="carburant" required>


                <label for="comments">Plus d'informations</label>
      <textarea id="comments"></textarea> 

    



            -->

                <label for="Carburant"><b>Carburant</b></label>

        <select id="Carburant" name="carburant">
        <option value=""> Faites votre choix </option>
        <option value="Diesel">Diesel</option>
        <option value="Essence">Essence</option>
        </select>


                 <label for="BoiteVitesse"><b>Boite de vitesse</b></label> 

        <select id="boiteVitesse" name="boiteVitesse">
        <option value=""> Faites votre choix </option>
        <option value="Manuelle">Manuelle</option>
        <option value="Automatique">Automatique</option>
        </select>

                <label><b>Kilométrage</b></label>
                <input type="text" name="kilometrage" required>

            

                 <label for="carteGrise"><b>Carte grise</b></label>

        <select id="carteGrise" name="carteGrise">
        <option value=""> Faites votre choix </option>
        <option value="Ajour">À jour</option>
        <option value="NestPasAjour">N'est pas à jour</option>
        </select>


 <label for="controleTechnique"><b>Controle technique</b></label>

        <select id="controleTechnique" name="controleTechnique">
        <option value=""> Faites votre choix </option>
        <option value="Moins de 6 mois">Moins de 6 mois </option>
        <option value="Sans controle technique">Sans controle technique</option>
        </select>


<label for="Kit de distribution"><b>kit de distribution</b></label> 

        <select id="kit_de_distribution" name="kit_de_distribution">
        <option value=""> Faites votre choix </option>
        <option value="En service">En service </option>
        <option value="A prévoir ">A prevoir</option>
        <input type="text"   placeholder="Plus d'informations sur la distribution"   name="distribution" required >
        </select>


<label for="Kit de d'embrayage"><b>kit d'embrayage</b></label> 

        <select id="kit_embrayage" name="kit_embrayage">
        <option value=""> Faites votre choix </option>
        <option value="En service">En service </option>
        <option value="A prévoir ">A prevoir</option>
        <input type="text"   placeholder="Plus d'informations sur l'embrayage" name="embrayage" required >
        </select>
    



            <label for="Volant moteur"><b>Volant moteur</b></label> 

        <select id="volant_moteur" name="volant_moteur">
        <option value=""> Faites votre choix </option>
        <option value="En service">En service </option>
        <option value="A prévoir ">A prevoir</option>
        <input type="text"   placeholder="Plus d'informations sur le volant moteur" name="le volant moteur" required >
        </select>
    


            <label for="Turbo"><b>Turbo</b></label> 

        <select id="turbo" name="turbo">
        <option value=""> Faites votre choix </option>
        <option value="En service">En service </option>
        <option value="A prévoir ">A prevoir</option>
        <input type="text"   placeholder="Plus d'informations sur le turbo" name="le turbo" required >
        </select>
    


                 
                
                <label><b>Plaquettes des freins</b></label>
                <input type="text" name="plaquettes" required> 

                <label><b>Vidange </b></label>
                <input type="text" name="vidange" required> 


                <label><b>Batterie</b></label>
                <input type="text" name="batterie" required>

                <label><b>Filtre air</b></label>
                <input type="text" name="filtreAir" required> 

                <label><b>Filtre huile</b></label>
                <input type="text" name="filtreHuile" required>  

                <label><b>Filtre carburant </b></label>
                <input type="text" name="filtreCarburant" required> 



                <input type="submit" name='submit' value="Publier" >

                 <?php
                 if(isset($_POST['submit'])){
                $servername = "localhost";                                             
                $username = "root";
                $password = "root";
                $dbname = "autoMarket";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }


                $sql = "INSERT INTO annonce (titre, prix, marque, modele, annee, carburant, boite_vitesse, kilometrage,carte_grise, controle_technique, kit_de_distribution, distribution, kit_embrayage,embrayage, volant_moteur,le volant moteur, turbo, le turbo, plaquette_frein,vidange, batterie, filtre_air, filtre_huile, filtre_carburant)
                VALUES ('".$_POST["titre"]."','".$_POST["prix"]."','".$_POST["marque"]."','".$_POST["modele"]."','".$_POST["annee"]."','".$_POST["carburant"]."','".$_POST["boiteVitesse"]."','".$_POST["kilometrage"]."','".$_POST["carteGrise"]."'  ,   '".$_POST["controleTechnique"]."', '".$_POST["kit_de_distribution"]."', '".$_POST["distribution"]."', '".$_POST["kit_embrayage"]."','".$_POST["embrayage"]."','".$_POST["volantMoteur"]."','".$_POST["le volant Moteur"]."',,'".$_POST["turbo"]."' ,'".$_POST["le turbo"]."','".$_POST["plaquettes"]."','".$_POST["vidange"]."','".$_POST["batterie"]."','".$_POST["filtreAir"]."','".$_POST["filtreHuile"]."','".$_POST["filtreCarburant"]."')";

                
                if ($conn->query($sql) === TRUE) {
                    echo "Votre annonce a été ajoutée avec succès";
                } else {
                    echo "Erreur: " . $sql . "<br>" . $conn->error;

                }

                $conn->close();
                }

                ?>
            </form>
        </div>
    </body>
</html>